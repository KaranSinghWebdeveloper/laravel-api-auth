<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiController extends Controller
{
    public function protectedRoute(Request $request)
    {
        return response()->json([
            'message' => 'You have accessed a protected route!',
            'user' => $request->user(),
        ]);
    }

    public function publicRoute()
    {
        return response()->json([
            'message' => 'This is a public route!'
        ]);
    }
}